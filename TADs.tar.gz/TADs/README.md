# Folder description

This folder contains original and transformed TADs, boundaries and loop anchors bed files. Original TAD and loop coordinates were obtained from Rao et al, 2014. available at: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE63525
Boundaries were computed in GM12878 using the Contact matrices and domain list from the above source and a custom script (twosteps_normahiC2boundaries.R)
# Contents

* original data: Contains TADs and loop anchors as called by Rao et al. using respectively their Arrowhead and HiCCUPs algorithms.
* boundaries: Boundaries defined using a custom script, based on contact matrices and domain lists from Rao et al. 
    + GM12878_HIC_boundaries.bed: Boundaries as produced from the custom script.
    + GM12878_shor_fullover_hicboundaries.bed: Boundaries filtered by removing those that are completely encompassing other boundaries using bedtools 2.26
    + ucsc_check.bed: Genome browser-friendly version (i.e. without TAD IDs column) of the filtered boundaries, used for GAT enrichment tests.
* short_fullover_TAD.bed: TADs after being filtered to remove all large TADs completely encompassing other smaller TADs. Filtered using bedtools 2.26
* short_fullover_bins10.bed: Bins of 10% TAD length computed from the filtered TADs.
