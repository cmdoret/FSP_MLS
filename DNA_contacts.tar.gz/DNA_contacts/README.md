# Folder description

This folder contains DNA-DNA contact data computed from the Hi-C matrices generated in Rao et al. 2014. Original, raw matrices are available on: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE63525
Primary + replicate  in-situ matrices with MAPQGE>30 have been used in all analyses.

# Contents


* diam_sums: Vectors containing sum of interactions across all positions in the genome, in GM12878 at a maximum range of 100kb for calculating TAD boundaries. These vectors have been obtained with the first step of the twosteps_normhiC2boundaries script.
* TAD_TAD_contact: Dataframes containing all genes belonging to a TAD and the averaged amount of contacts in their respective TAD. If a gene spans multiple TADs, it is listed multiple times with the contact value associated with each TAD.
