# Folder description

This folder contains data for expression in different tissues from ENCODE and tissue specificity indexes computed from these expression values. Tissue specificity index (tau) was computed using the method described in Kryuchkova and Robinson-Rechavi 2015 with a cutoff of 0.1 (all expression values <0.1 are set to 0).

# Contents

* original_data: 
    + all.lincRNA.tissue.encode.txt:  Original expression matrix across tissues for lincRNAs, available on ENCODE
    + all.pcgene.tissue.encode.txt: Original expression matrix across tissues for protein-coding genes, available on ENCODE.
    + xloc2ensg: File containing XLOC gene IDs and their corresponding ENS ID.
* whole_tau.txt: Processed data. All genes expressed in GM12878, along with their tissue specificity index and promoter/enhancer overlap status, used for classification of elincRNAs/other lincRNAs.
