# Folder description

This folder contains median expression levels in GM12878, NHEK, HUVEC and K562, for all genes used in analyses. Data was obtained from ENCODE.

# Contents

* original data: Averaged expression levels computed from the ENCODE expression matrices.
* whole_cons.txt: Table containing genes with their category (promoter/enhancer overlap status) and median expression levels in all 4 cell lines.
