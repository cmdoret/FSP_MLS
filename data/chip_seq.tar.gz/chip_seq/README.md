# Folder description

This folder contains ChIP-seq peaks for CTCF and 2 subunits of cohesin (SMC3 and RAD21) in GM12878.

# Contents

* original: peaks files as available on ENCODE.
* inter_insulators_GM12878: Different sets obtained by performing logical operations on the original subsets (exclusion and intersections). Used for enrichment analyses and building a Venn diagram.
