# Folder description

This folder contains sequence conservation data measured using phastCons scores for all GM12878-expressed lincRNAs and protein-coding genes, pre-computed by Jennifer Tan.

# Contents

* original data: table containing average phastCons scores for all protein-coding genes and lincRNAs.
* whole_cons.txt: summary table containing average phastCons scores for all genes along with their category based on overlap with regulatory elements as described in the report.
