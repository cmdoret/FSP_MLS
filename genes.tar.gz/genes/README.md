# Folder description

This folder contains the different sets of genes used for analyses. These sets have been generated using bedtools 2.26 by intersecting the promoter regions (1kb upstream of TSS) of the original sets with regulatory elements.

# Contents

* original sets: LincRNAs and protein coding genes expressed in GM12878 available on ENCODE
* regulatory elements: predicted active enhancers and promoters available on ENCODE. Promoters have been manually extracted, while enhancers were readily available on http://info.gersteinlab.org/Encode-enhancers
* e.np_linc_pr.bed: elincRNAs defined as having enhancers, but no promoter overlapping their promoter region.
* ne.np_linc_pr.bed: other lincRNAs defined as having neither enhancer nor promoters overlapping their promoter region.
* LCL.expressed.pcgene.bed: Set of protein coding genes expressed in GM12878, not modified.
