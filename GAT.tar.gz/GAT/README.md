# Folder description

This folder contains the workspaces, isochore and output for GAT enrichment tests performed in the report. All enrichment tests are performed in GAT 1.2, using nsamples=10'000, nbuckets = 270'000 and segment overlap as the measure of enrichment.

# Contents

* out:
    + 10ksamples: contains raw outputs for all GAT enrichment tests shown in the report.
    + whole_seg_10kgat_anchors.txt: Output summary for enrichment test of lincRNAs at loop anchors.
    + whole_seg_10kgat_exclu_insul_bs.txt Output summary for enrichment test of CTCF and cohesin exclusive peaks in lincRNAs
    + whole_seg_10kgat_fullover_results.txt: Output summary for enrichment test of lincRNAs in 10% TAD bins and enrichment of CTCF/SMC3/RAD21 peaks in lincRNAs.
    + whole_seg_10kgat_hic_boundaries.txt: Output summary for enrichment test of lincRNAs in custom-defined boundaries.
* workspaces:
    + all_pc_genes.bed: protein-coding space of the genome. Not used in the report, could be used as a workspace for enrichment of protein-coding genes.
    + hg19.genome.bed.gat: Whole genome workspace. Used when testing for enrichment of anchors at boundaries.
    + intergenic workspace: used when testing for enrichment of lincRNAs in any annotation, or enrichment of insulator proteins peaks in lincRNAs.
* hg19.fa.corr_term_ISOisochore.bed: Isochore file for the hg19 assembly.

# File names

For all raw GAT output files, filenames are structured as follow: 
log files begin with "log", results files begin with "gat".
typical file name for a gat result: gat_W_<workspace>_S_<segment>_A_<annotation>.tsv

# Details

TAD bins and boundaries are computed from the short_fullover_TAD.bed file (i.e. TAD from Rao et al. 2014 after being filtered for large, encompassing TADs).
